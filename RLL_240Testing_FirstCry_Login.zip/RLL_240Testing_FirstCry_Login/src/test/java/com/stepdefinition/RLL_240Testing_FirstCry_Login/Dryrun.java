//package com.stepdefinition.RLL_240Testing_FirstCry_Login;
//import java.io.IOException;
// 
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import com.pages.RLL_240Testing_FirstCry_Login.LoginPage;
//public class Dryrun {
// 
//	public static void main(String[] args) throws InterruptedException, IOException {
//		// TODO Auto-generated method stub
// 
//		WebDriver driver ;
//		driver = new ChromeDriver();
//		LoginPage login = new LoginPage( driver );
// 
//		login.LaunchFirstCry();
//		driver.manage().window().maximize();
//		Thread.sleep(1000);
//		login.loginbuttonclick();
//		Thread.sleep(1000);
//		login.enterUserName();
//		Thread.sleep(1000);
//		login.clickContinueButton();
//		Thread.sleep(31000);
//		login.clickSubmitButton();
// 
//	}
// 
//}
